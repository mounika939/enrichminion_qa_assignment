const { test, expect } = require('@playwright/test');

test('Login to Enrich Minion', async ({ page }) => {
  await page.goto('https://enrichminion.vercel.app/enrichment/phone-finder');

  // Fill email
  await page.locator('xpath=//*[@id="email"]').first().fill('your-email@example.com');

  // Fill password
  await page.locator('xpath=//*[@id="password"]').first().fill('your-password');

  // Click the first Login button
  await page.locator('xpath=//*[@id="auth-sign-in"]/div/button').nth(0).click({ force: true });

  // Optional: Wait for confirmation or redirect
  await page.waitForTimeout(3000);
});

