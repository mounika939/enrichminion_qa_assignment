const { test, expect } = require('@playwright/test');

test('Register on Enrich Minion', async ({ page }) => {
  await page.goto('https://enrichminion.vercel.app/enrichment/phone-finder');

  // Fill email
  await page.locator('xpath=//*[@id="email"]').first().fill('your-email@example.com');

  // Fill password
  await page.locator('xpath=//*[@id="password"]').first().fill('your-password');

  // Force click Register button
  await page.locator('xpath=//*[@id="auth-sign-up"]/div/button').click({ force: true });

  // Optional: Wait for confirmation or redirect
  await page.waitForTimeout(3000);
});
