// playwright.config.js
module.exports = {
  use: {
    headless: false,
    baseURL: 'https://example.com',
    viewport: { width: 1280, height: 720 },
  },
  testDir: './tests',
};
